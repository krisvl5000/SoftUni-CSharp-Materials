﻿using System;

namespace Zoo
{
    internal class StartUp
    {
        static void Main(string[] args)
        {


        }
    }
}