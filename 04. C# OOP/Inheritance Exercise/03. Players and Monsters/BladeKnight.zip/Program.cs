﻿using System;

namespace Players
{
    public class StartUp
    {
        static void Main(string[] args)
        {


        }
    }
}