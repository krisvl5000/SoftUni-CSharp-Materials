﻿namespace CommandPattern
{
    public interface IEngine
    {
        void Run();
    }
}