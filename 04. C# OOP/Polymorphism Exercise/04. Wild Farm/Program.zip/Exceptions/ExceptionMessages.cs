﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFarm
{
    public static class ExceptionMessages
    {
        public const string FOOD_NOT_EDIBLE_EXCEPTION_MESSAGE = 
            "{0} does not eat {1}!";
    }
}
