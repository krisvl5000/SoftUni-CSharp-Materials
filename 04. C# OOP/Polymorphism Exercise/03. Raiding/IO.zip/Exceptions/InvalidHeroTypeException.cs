﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding
{
    public class InvalidHeroTypeException : Exception
    {
        public InvalidHeroTypeException(string message) : base(message)
        {

        }
    }
}
