﻿using System;
using BoxOfT;

namespace BoxOfT
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            

        }
    }
}